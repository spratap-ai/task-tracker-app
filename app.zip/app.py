from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def home():
    return """
    <h1>Task Tracker App</h1>
    <p>My first Azure deployment project 🚀</p>
    """

@app.route('/about')
def about():
    return "<h2>This app is running using Flask!</h2>"

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 8000))
    app.run(host='0.0.0.0', port=port)